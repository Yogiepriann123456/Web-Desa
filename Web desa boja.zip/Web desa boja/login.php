<?php if (isset($_GET['error'])): ?>
  <script>
    alert("Anda harus log in dahulu");
    document.location.href='index.php'
  </script>
<?php endif; ?>
